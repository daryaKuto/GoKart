class Example {
  public static void main(String[] args) {
    GoKart kart = new GoKart("purple");
    if (kart.isBatteryEmpty()) {
      System.out.println("The battery is empty");
    }
    try {
            kart.drive(2);
        } catch(IllegalArgumentException iae){
            System.out.println(iae.getMessage());
        }
  }
}